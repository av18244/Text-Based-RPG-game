from text_based_rpg.play import play

if __name__ == "__main__":
    play()
