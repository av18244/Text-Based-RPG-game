import time

input_ = input
print_ = print
sleep = time.sleep
